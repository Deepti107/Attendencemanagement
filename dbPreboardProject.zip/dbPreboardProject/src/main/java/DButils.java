import model.Class_Table;
import model.User_Table;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DButils {
    //Table Names
    public static final String User_Table = "User";
    public static final String Class_Table = "Class";

    public static final String Attendence_Table = "Attendance";
    public static final String Class_name = "class_name";
    public static final String id = "id";
    public static final String  user_name = "user_name";
    public static final String password = "password";
    public static Connection connect() {

        Connection connect = null;

        String url = "jdbc:sqlite:src/main/resources/database/Attendencedb.db";

        try {
            connect = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return connect;
    }


    public static void insert_user(Connection conn, User_Table x) {

        String sql = "INSERT INTO " + User_Table + " (username,password)" + "VALUES (?,?)";


        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(sql);
            statement.setString(1, x.getUser_name());
            statement.setString(2, x.getPassword());
            statement.execute();
            statement.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


    }
    public static void insert_class(Connection conn, Class_Table k) {

        String sql = "INSERT INTO " + Class_Table + " (classname)" + "VALUES (?)";


        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(sql);
            statement.setString(1, k.getClass_name());
            statement.execute();
            statement.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


    }
    public static void insert_attendence(Connection conn,User_Table x,Class_Table k){
        String sql = "INSERT INTO " + Attendence_Table + " (userid,classid)" + "VALUES (?,?)";


        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(sql);
            statement.setInt(1, x.getId());
            statement.setInt(2, k.getId());
            statement.execute();
            statement.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static List<User_Table> display_user(Connection conn) {

        String sql = "SELECT * FROM " + User_Table;

        List<User_Table> user_list;
        user_list = new ArrayList<>();

        try {
            Statement statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int x_id = rs.getInt(id);
                String x_username = rs.getString(user_name);
                String x_password = rs.getString(password);
                User_Table user_data = new User_Table(x_id, x_username,x_password);
                user_list.add(user_data);

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return user_list;
    }

    public static List<Class_Table> display_class(Connection conn) {

        String sql = "SELECT * FROM " + Class_Table;

        List<Class_Table> class_list;
        class_list= new ArrayList<>();

        try {
            Statement statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int class_id = rs.getInt(id);
                String class_name = rs.getString(Class_name);
                Class_Table class_data = new Class_Table(class_id, class_name);
                class_list.add(class_data);

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return class_list;
    }
}























