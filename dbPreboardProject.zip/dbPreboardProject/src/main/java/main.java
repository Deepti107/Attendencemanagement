import model.Class_Table;
import model.User_Table;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
    Connection conn = DButils.connect();
    Scanner sc = new Scanner(System.in);
    List<User_Table> user_list = DButils.display_user(conn);
    List<Class_Table> class_list = DButils.display_class(conn);

    //        System.out.println(conn);
    boolean end = false;

        while(!end){
        System.out.println("\n\n1. Insert User");
        System.out.println("2. Insert Classes");
        System.out.println("3. Insert Attendance");
        System.out.println("4. Display All Users");
        System.out.println("5. Display All Classes");
        System.out.println("6. End\n\n");
        int choice = sc.nextInt();

        switch(choice){
            case 1:
                System.out.println("Enter your username:");
                String username = sc.next();
                System.out.println("Enter your desired password:");
                String password = sc.next();
                User_Table user = new User_Table(0,username,password);
                DButils.insert_user(conn,user);

                break;
            case 2:
                System.out.println("Enter your classname:");
                String classname = sc.next();
                Class_Table classobject = new Class_Table(0,classname);
                DButils.insert_class(conn,classobject);
                break;
            case 3:
                System.out.println("Enter your username:");
                username = sc.next();


                for (User_Table x : user_list ) {
                    if(username.equals(x.getUser_name())){
                        System.out.println("Enter your password:");
                        password = sc.next();
                        if( password.equals(x.getPassword())){
                            System.out.println("Enter your classname:");
                            classname = sc.next();

                            user = new User_Table(0,username,password);
                            classobject = new Class_Table(0,classname);
                            DButils.insert_attendence(conn,user,classobject);
                        }
                    }
                }


                break;
            case 4:
                conn = DButils.connect();
                user_list = DButils.display_user(conn);
                for (User_Table x : user_list ) {
                    System.out.println(x.getId()+"."+" Name: " + x.getUser_name());
                }
                break;
            case 5:
                conn = DButils.connect();
                class_list = DButils.display_class(conn);
                for (Class_Table k : class_list ) {
                    System.out.println(k.getId()+"."+" Name: " + k.getClass_name());
                }
                break;
            case 6:
                end = true;
                break;

            default:
                System.out.println("Enter Valid Number.");
                break;
        }
    }
}
}