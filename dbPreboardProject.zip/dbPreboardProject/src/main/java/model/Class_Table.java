package model;

public class Class_Table {
    int class_id;
    String class_name;

    public int getId() {
        return class_id;
    }

    public void setId(int id) {
        this.class_id = id;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public Class_Table(int id, String class_name) {
        this.class_id = class_id;
        this.class_name = class_name;
    }
}
